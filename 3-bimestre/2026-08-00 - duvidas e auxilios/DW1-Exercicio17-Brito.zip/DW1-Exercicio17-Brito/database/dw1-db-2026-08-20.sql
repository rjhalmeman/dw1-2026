DROP TABLE IF EXISTS public.jogo;

CREATE TABLE public.jogo (
    id_jogo INTEGER PRIMARY KEY,
    nome_jogo VARCHAR(100) NOT NULL,
    desenvolvedora VARCHAR(100) NOT NULL,
    data_lancamento DATE NOT NULL,
    plataforma VARCHAR(100) NOT NULL
);

-- Inserindo alguns dados de exemplo
INSERT INTO public.jogo (id_jogo, nome_jogo, desenvolvedora, data_lancamento, plataforma) VALUES
(1, 'Crash Bandicoot', 'Naughty Dog', '09-09-1996', 'PlayStation'),
(2, 'Spyro the Dragon', 'Insomniac Games', '09-09-1998', 'PlayStation'),
(3, 'Rayman', 'Ubi Soft Entertainment', '01-09-1995', 'PlayStation');