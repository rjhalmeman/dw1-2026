const URL_API = 'http://localhost:3001';

let oQueEstaFazendo = '';
let cargo = null;
bloquearAtributos(true);

async function inicializar() {
    await listar();
}

async function procurePorChavePrimaria(chave) {
    try {
        const resposta = await fetch(`${URL_API}/cargo/${chave}`);
        const data = await resposta.json();
        return data.sucesso ? data.cargo : null;
    } catch (erro) {
        return null;
    }
}

async function procure() {
    const id_cargo = document.getElementById("inputId_cargo").value;

    if (isNaN(id_cargo) || !Number.isInteger(Number(id_cargo)) || id_cargo === "") {
        mostrarAviso("Precisa ser um número inteiro");
        return;
    }

    cargo = await procurePorChavePrimaria(id_cargo);
    oQueEstaFazendo = '';

    if (cargo) {
        mostrarDadoscargo(cargo);
        visibilidadeDosBotoes('inline', 'none', 'inline', 'inline', 'none');
        mostrarAviso("Achou no banco, pode alterar ou excluir");
    } else {
        limparAtributos();
        document.getElementById("inputId_cargo").value = id_cargo;
        visibilidadeDosBotoes('inline', 'inline', 'none', 'none', 'none');
        mostrarAviso("Não achou no banco, pode inserir");
    }
}

function inserir() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'inserindo';
    mostrarAviso("INSERINDO - Digite os atributos e clique em salvar");
}

function alterar() {
    bloquearAtributos(false);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'alterando';
    mostrarAviso("ALTERANDO - Digite os atributos e clique em salvar");
}

function excluir() {
    bloquearAtributos(true);
    visibilidadeDosBotoes('none', 'none', 'none', 'none', 'inline');
    oQueEstaFazendo = 'excluindo';
    mostrarAviso("EXCLUINDO - Clique em salvar para confirmar a exclusão");
}

async function salvar() {

    // Pega o valor do campo onde está o ID do cargo
    let id_cargo = document.getElementById("inputId_cargo").value;

    // Pega o valor do campo onde está o nome do cargo
    const nome_cargo = document.getElementById("inputNome_cargo").value;

    // Cria um objeto com os dados que serão enviados para o servidor
    const dadoscargo = { id_cargo, nome_cargo };

    try {

        // Verifica se a operação escolhida foi inserir
        if (oQueEstaFazendo === 'inserindo') {

            // Envia os dados para a rota /cargo usando o método POST
            await fetch(`${URL_API}/cargo`, {

                // Define que estamos cadastrando um novo cargo
                method: 'POST',

                // Informa que os dados enviados estão no formato JSON
                headers: {
                    'Content-Type': 'application/json'
                },

                // Transforma os dados do cargo em JSON para enviar ao servidor
                body: JSON.stringify(dadoscargo)
            });

            // Mostra uma mensagem informando que o cadastro foi realizado
            mostrarAviso("Inserido no Banco de Dados com sucesso!");

        // Verifica se a operação escolhida foi alterar
        } else if (oQueEstaFazendo === 'alterando') {

            // Envia os dados para o cargo que possui o ID informado
            await fetch(`${URL_API}/cargo/${id_cargo}`, {

                // Define que estamos alterando um cargo existente
                method: 'PUT',

                // Informa que os dados enviados estão no formato JSON
                headers: {
                    'Content-Type': 'application/json'
                },

                // Transforma os dados do cargo em JSON
                body: JSON.stringify(dadoscargo)
            });

            // Mostra uma mensagem informando que o cargo foi alterado
            mostrarAviso("Alterado no Banco de Dados com sucesso!");

        // Verifica se a operação escolhida foi excluir
        } else if (oQueEstaFazendo === 'excluindo') {

            // Envia uma solicitação para excluir o cargo pelo ID
            await fetch(`${URL_API}/cargo/${id_cargo}`, {

                // Define que estamos excluindo o cargo
                method: 'DELETE'
            });

            // Mostra uma mensagem informando que o cargo foi excluído
            mostrarAviso("Excluído do Banco de Dados!");
        }

        // Depois da operação, mostra somente o botão Procurar
        visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');

        // Limpa os dados dos campos
        limparAtributos();

        // Limpa o campo do ID
        document.getElementById("inputId_cargo").value = "";

        // Atualiza a lista de cargos na tela
        await listar();

    // Se acontecer algum erro durante a operação, entra aqui
    } catch (erro) {

        // Mostra uma mensagem informando que ocorreu um erro
        mostrarAviso("Erro ao efetuar operação no servidor.");
    }
}

async function listar() {
    try {
       // alert("aqui "+ data.stringify())
        const resposta = await fetch(`${URL_API}/cargo/listarCargo`);
        const data = await resposta.json();
        if (data.sucesso) {
            let texto = "";

            for (let linha of data.cargo) {
                texto += `${linha.id_cargo} - ${linha.nome_cargo}<br>`;
            }

            document.getElementById("outputSaida").innerHTML =
                texto || "Nenhum cargo cadastrado.";
        }

    } catch (erro) {
        document.getElementById("outputSaida").innerHTML = "Servidor offline."+ erro;
    }
}

function cancelarOperacao() {
    limparAtributos();
    bloquearAtributos(true);
    visibilidadeDosBotoes('inline', 'none', 'none', 'none', 'none');
    mostrarAviso("Cancelou a operação");
}

function mostrarAviso(mensagem) {
    document.getElementById("divAviso").innerHTML = mensagem;
}

function mostrarDadoscargo(p) {
    document.getElementById("inputId_cargo").value = p.id_cargo;
    document.getElementById("inputNome_cargo").value = p.nome_cargo;
    bloquearAtributos(true);
}

function limparAtributos() {
    cargo = null;
    oQueEstaFazendo = '';
    document.getElementById("inputNome_cargo").value = "";
    bloquearAtributos(true);
}

function bloquearAtributos(soLeitura) {
    document.getElementById("inputId_cargo").readOnly = !soLeitura;
    document.getElementById("inputNome_cargo").readOnly = soLeitura;
}

function visibilidadeDosBotoes(btP, btI, btA, btE, btS) {
    document.getElementById("btProcure").style.display = btP;
    document.getElementById("btInserir").style.display = btI;
    document.getElementById("btAlterar").style.display = btA;
    document.getElementById("btExcluir").style.display = btE;
    document.getElementById("btSalvar").style.display = btS;
    document.getElementById("btCancelar").style.display = btS;
}
